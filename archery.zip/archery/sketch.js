var archerimg
var archer
var enemy
var arrow
var arrowImage
var bow
var enemy1Image
var enemyImage


function preload(){
  archerimg=loadAnimation("archery/man0.png","archery/man1.png","archery/man2.png","archery/man3.png","archery/man4.png","archery/man5.png","archery/man6.png","archery/man7.png",
  "archery/man8.png","archery/man9.png","archery/man10.png","archery/man11.png","archery/man12.png","archery/man13.png"
  )
  archerimg1=loadAnimation("archery/man14.png")

  archerimg2=loadAnimation("archery/man15.png")

  archerimg3=loadAnimation("archery/man16.png","archery/man17.png","archery/man18.png","archery/man19.png")

  archerimg4=loadAnimation("archery/man20.png","archery/man21.png","archery/man22.png","archery/man23.png",
  "archery/man24.png","archery/man25.png","archery/man26.png")

  archerimg5=loadAnimation("archery/man34.png","archery/man35.png","archery/man36.png","archery/man37.png",
  "archery/man38.png","archery/man39.png","archery/man40.png")

  bg1=loadImage("bg5.png")

  arrowImage=loadImage("arrow.png")

  enemyImage=loadImage("enemy.png")
  enemy1Image=loadImage("enemy1.jpg")
  
}

function setup() {
  createCanvas(1000,500)

  archerstand=createSprite(340,400,30,234)

  archerstand.addAnimation("attack",archerimg)
  
  archerstand.addAnimation("set",archerimg1)
  
  archerstand.addAnimation("stand",archerimg2)
  archerstand.scale=0.4

   archerstand.addAnimation("magic",archerimg3)
 
  archerstand.addAnimation("kill",archerimg4)
  
  archerstand.addAnimation("walk",archerimg5)

  
 
}
function draw() {
  background(bg1)
  camera.x=archerstand.x
  camera.y=archerstand.y
 // archerstand.addAnimation("stand",archerimg2)

  if(keyDown("w")){
    archerstand.changeAnimation("attack",archerimg)
  }

  if(keyDown("a")){
    archerstand.changeAnimation("set",archerimg1)
  }

  if(keyDown("s")){
    archerstand.changeAnimation("stand",archerimg1)

  }

  if(keyDown("c")){
    archerstand.changeAnimation("magic",archerimg3)
  }

  if(keyDown("v")){
    archerstand.changeAnimation("kill",archerimg1)
  }

  if(keyDown("d")){
    archerstand.changeAnimation("walk",archerimg1)
    archerstand.x=archerstand.x+30
    camera.x=camera.x+30
    
  }
 
   // release arrow when space key is pressed
   if (keyDown("space")) {
    var temp_arrow = createArrow();
    temp_arrow.addImage(arrowImage);
  }

  
  drawSprites()
  
}
function createArrow() {
  arrow= createSprite(archerstand.x,archerstand.y, 5, 10);
  arrow.velocityX = 6;
  arrow.scale = 0.3;
  return arrow;
}                
